name = 'Deep-Live-Cam'
version = '1.8'
edition = 'GitHub Edition'
