#!/usr/bin/env python3

from modules import core

if __name__ == '__main__':
    core.run()
